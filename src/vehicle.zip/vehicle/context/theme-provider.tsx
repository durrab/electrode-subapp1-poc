import * as React from 'react'
import { ThemeProvider, createMuiTheme, responsiveFontSizes } from '@material-ui/core/styles'

/**
 * UI theme based on livingstyle design guide (https://livingdesign.walmart.com)
 */
function CostThemeProvider({ children }) {
  let theme = createMuiTheme({
    props: {
      MuiButtonBase: {
        disableRipple: true,
      },
    },
    transitions: {
      create: () => 'none',
    },
    palette: {
      type: 'light',
      common: {
        black: '#000000',
        white: '#ffffff',
      },
      primary: {
        main: '#041E42',
        contrastText: '#fff',
      },
      action: {
        active: '#efefef',
      },
      secondary: {
        main: '#214779',
        contrastText: '#000',
      },
      error: {
        main: '#041E42',
        contrastText: '#fff',
      },
      text: {
        primary: 'rgba(0, 0, 0, .87)',
        secondary: 'rgba(0, 0, 0, .6)',
        disabled: 'rgba(0, 0, 0, .38)',
        hint: 'rgba(0, 0, 0, .38)',
      },
      divider: 'rgba(0, 0, 0, .20)',
    },
    typography: {
      fontFamily: [
        'Bogle',
        'Roboto',
        'Helvetica Neue',
        'Arial',
        'Apple Color Emoji',
        'Segoe UI Emoji',
        'Segoe UI Symbol',
      ].join(','),
    },
    overrides: {
      MuiButton: {
        contained: {
          borderRadius: '20px',
          letterSpacing: '1pt',
          fontWeight: 400,
          border: 'none',
          textTransform: 'uppercase',
          transitionDuration: '0s',
        },
        containedPrimary: {
          backgroundColor: '#041e42',
          '&:hover': {
            backgroundColor: '#041e42',
          },
        },
      },
      MuiIconButton: {
        root: {
          color: '#000000',
        },
      },
      MuiDialog: {
        paper: {
          zIndex: 99,
        },
      },
      MuiListItem: {
        root: {
          paddingTop: '4px',
          paddingBottom: '4px',
        },
        gutters: {
          paddingLeft: 0,
          paddingRight: 0,
        },
      },
      MuiPaper: {
        root: {
          minHeight: '100px',
          padding: '10px',
          marginTop: '25px',
        },
      },
      MuiInputBase: {
        root: {
          minWidth: '75px',
          borderRadius: '4px',
        },
      },
      MuiOutlinedInput: {
        input: {
          padding: '8px 12px',
        },
      },
      MuiSelect: {
        iconOutlined: {
          color: 'rgba(0, 0, 0, .3)',
        },
      },
      MuiDivider: {
        root: {
          backgroundColor: 'var(--living-design-grey-50)',
        },
      },
      MuiBackdrop: {
        root: {
          position: 'absolute',
          backgroundColor: 'rgba(255, 255, 255, 0.5)',
          zIndex: 2,
        },
      },
      MuiTooltip: {
        tooltip: {
          backgroundColor: 'var(--living-design-black)',
          fontSize: '14px',
        },
        arrow: {
          color: 'var(--living-design-black)',
        },
      },
    },
  })
  theme = responsiveFontSizes(theme)

  return <ThemeProvider theme={theme}>{children}</ThemeProvider>
}

export { CostThemeProvider }
