import * as React from 'react'
import { QueryClientProvider } from './query-client'
import { CostThemeProvider } from './theme-provider'

function AppProviders({ children }) {
  return (
    <QueryClientProvider>
      <CostThemeProvider>{children}</CostThemeProvider>
    </QueryClientProvider>
  )
}

export { AppProviders }
