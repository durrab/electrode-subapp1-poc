import * as React from 'react'
import { QueryClient, QueryClientProvider as RQProvider } from 'react-query'

// Make sure there is only one instance
function useConstant(initializer) {
  return React.useState(initializer)[0]
}

function QueryClientProvider({ children }) {
  const queryClient = useConstant(() => {
    const client = new QueryClient({
      defaultOptions: {
        queries: {
          useErrorBoundary: true,
          refetchOnWindowFocus: false,
        },
      },
    })
    return client
  })

  return <RQProvider client={queryClient}>{children}</RQProvider>
}

export { QueryClientProvider }
