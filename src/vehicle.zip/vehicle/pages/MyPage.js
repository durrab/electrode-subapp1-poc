import React from 'react'



const MyPage = () => {


  return (
    <ErrorBoundary FallbackComponent={() => <div>Error here</div>} onError={logError}>
    <div>My Vehicle Page</div>
    </ErrorBoundary>
  )
}

export default MyPage
