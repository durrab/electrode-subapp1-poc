import { getBrowserHistory, React } from 'subapp-react'
import { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { reduxLoadSubApp } from 'subapp-redux'
import { Route, Router } from 'react-router-dom'
import Main from './Main'
import { reducers as costReducers } from './reducers'
import LoadSubapp from '../common/load-subapp'

const App = () => {
  return <Main />
}

export default reduxLoadSubApp({
  name: 'Vehicle',
  Component: App,
  useReactRouter: true,
  reduxReducers: costReducers,
  reduxShareStore: true,
  StartComponent: (props) => {
    return (
      <Router history={getBrowserHistory()}>
         <Route path='/' exact render={() => <LoadSubapp dynamic name='Home' />} />
        <Route path='/vehicle'>
          <App {...props} />
        </Route>
      </Router>
    )
  },
})
