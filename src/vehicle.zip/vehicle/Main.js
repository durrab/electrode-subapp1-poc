import React from 'react'
import { Route, Switch, Redirect } from 'react-router-dom'
import { ErrorBoundary } from 'react-error-boundary'
import MyPage from './pages/MyPage'
//import { AppProviders } from './context'
import './styles/global.css'

const AppRoutes = () => {


  return (
    <>
      <Switch>
          <Route
            path={'/'}
            exact
            render={() => <Redirect to='/list' />}
          />
          <Route path='/list' component={MyPage} />
        </Switch>
    </>
  )
}

const Main = () => {
  return (
    <AppProviders>
      <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
        <div>
          <div>
            <AppRoutes />
          </div>
        </div>
      </ErrorBoundary>
    </AppProviders>
  )
}

export default Main
