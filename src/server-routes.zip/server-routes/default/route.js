"use strict";

module.exports = {
  path: [
    "/",
    { "/home": ["post"] },
    "/list",
    "/search/{any*}",
    "/stores",
    "/contact",
  ],
  pageTitle: "Cerence Vehicles",
  templateFile: "index"
};
