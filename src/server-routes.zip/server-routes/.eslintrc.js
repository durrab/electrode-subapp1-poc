const { eslintNodeRc } = require("@xarc/app-dev");

module.exports = {
  extends: eslintNodeRc
};
