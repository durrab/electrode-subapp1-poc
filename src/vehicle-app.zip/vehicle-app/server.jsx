import React from "react";
import subApp from "./vehicle-app";
import Promise from "bluebird";
import { StaticRouter } from "react-router-dom";

module.exports = {
  prepare: async ({ request, context }) => {
    return Promise.delay(50 + Math.random() * 1000)
      .return({
        number: { value: 999 },
        items: [
          {
            heading: "BLACK FRIDAY DEAL",
            footer: `VIZIO 50” Class 4K Ultra HD LED TV`,
            type: "danger"
          },
        ]
      })
      .then(initialState => {
        return { initialState };
      });
  },
  StartComponent: props => {
    return (
      <StaticRouter {...props}>
        <subApp.Component />
      </StaticRouter>
    );
  }
};

console.log("hello from main-body server.jsx");
