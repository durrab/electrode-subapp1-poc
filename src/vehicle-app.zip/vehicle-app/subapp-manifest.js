module.exports = {
  type: "app",
  name: "VehicleApp",
  entry: "vehicle-app",
  serverEntry: "./server"
};
