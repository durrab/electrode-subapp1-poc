import { reduxLoadSubApp } from "subapp-redux";
import { React, getBrowserHistory, AppContext } from "subapp-react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { Router, Route, Switch } from "react-router-dom";
import { Products } from "../components/products";
import { Deals } from "../components/deals";
import reduxReducers from "./reducers";
import {SearchVehicle} from "../pages/SearchVehicle";

/*
 <div>SubApp name: {subApp ? subApp.name : "Not Available from context"}</div>
            <div>
              IS_SSR: {`${Boolean(isSsr)}`} HAS_REQUEST: {ssr && ssr.request ? "yes" : "no"}
            </div>
*/

const Home = () => {
  return (
    <AppContext.Consumer>
      {({ isSsr, ssr, subApp }) => {
        return (
          <div className="container-fluid text-center">
            <p>Vehicles App</p>
          </div>
        );
      }}
    </AppContext.Consumer>
  );
};

const Stores = () => `Stores`;
const Contact = () => `Contact`;

const SearchVehiclePage = props => {
  return <SearchVehicle/>
}

const MainBody = props => {
  return (
    <div>
      <Switch>
        <Route path="/" exact component={Home} {...props} />
        <Route path="/list" component={Products} {...props} />
        <Route path="/search" component={SearchVehiclePage} {...props} />
        <Route path="/stores" component={Stores} {...props} />
        <Route path="/contact" component={Contact} {...props} />
      </Switch>
    </div>
  );
};

const mapStateToProps = state => state;

const Component = withRouter(connect(mapStateToProps, dispatch => ({ dispatch }))(MainBody));

export default reduxLoadSubApp({
  name: "VehicleApp",
  Component,
  useReactRouter: true,

  StartComponent: props => {
    return (
      <div>
        {" "}
        <Router history={getBrowserHistory()}>
          <Component {...props} />
        </Router>
      </div>
    );
  },

  prepare: async () => {},

  reduxShareStore: true,
  reduxReducers
});
